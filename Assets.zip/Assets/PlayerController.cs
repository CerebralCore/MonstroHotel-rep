using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private float MoveInputX;
    private float MoveInputY;
    public float speed;
    private Rigidbody2D rb;
    private Animator anim;

    public float offset;
    private void Start()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
    }
    void FixedUpdate()
    {
        Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
        float rotZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0f, 0f, rotZ + offset);

        MoveInputY = Input.GetAxis("Vertical");
        MoveInputX = Input.GetAxis("Horizontal");
        //Walking
        if (MoveInputX != 0 || MoveInputY != 0)
        {
            rb.linearVelocity = new Vector2(MoveInputX * speed, MoveInputY * speed); // Movement
            anim.SetBool("isWalking", true); //AnimationControl
        }
        //standing
        else
        { 
            anim.SetBool("isWalking", false); //AnimationControl
        }
    }

}
